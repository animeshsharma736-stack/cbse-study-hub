'use client';

export default function Home() {
  return (
    <>
      {/* Navigation */}
      <nav className="sticky top-0 bg-white border-b border-gray-200 px-8 py-4 flex justify-between items-center z-100 shadow-sm">
        <div className="text-2xl font-bold bg-gradient-to-r from-purple-500 to-pink-600 bg-clip-text text-transparent">
          📚 CBSE Hub
        </div>
        <ul className="flex gap-8 list-none">
          <li><a href="#subjects" className="text-gray-800 text-sm hover:text-purple-500 transition">Subjects</a></li>
          <li><a href="#features" className="text-gray-800 text-sm hover:text-purple-500 transition">Why Us</a></li>
          <li><a href="#testimonials" className="text-gray-800 text-sm hover:text-purple-500 transition">Reviews</a></li>
          <li><a href="#contact" className="text-gray-800 text-sm hover:text-purple-500 transition">Contact</a></li>
        </ul>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-purple-500 via-purple-600 to-pink-600 text-white py-24 px-8 text-center min-h-screen flex flex-col justify-center items-center">
        <h1 className="text-5xl font-bold mb-6 leading-tight">Master CBSE with Confidence</h1>
        <p className="text-xl opacity-95 max-w-2xl mx-auto mb-8 font-light">
          Expert study notes, practice questions, and past papers for all 12 subjects. Study smarter, not harder.
        </p>
        <div className="flex gap-4 justify-center flex-wrap mb-12">
          <button 
            onClick={() => document.getElementById('subjects')?.scrollIntoView({behavior: 'smooth'})}
            className="bg-white text-purple-600 px-8 py-3 rounded-lg font-semibold hover:shadow-lg hover:-translate-y-1 transition"
          >
            Explore Now
          </button>
          <button 
            onClick={() => document.getElementById('features')?.scrollIntoView({behavior: 'smooth'})}
            className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white/10 hover:-translate-y-1 transition"
          >
            Learn More
          </button>
        </div>
        <div className="flex gap-12 flex-wrap justify-center">
          <div className="text-center">
            <div className="text-4xl font-bold">50,000+</div>
            <div className="text-sm opacity-85">Active Learners</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold">800+</div>
            <div className="text-sm opacity-85">Study Resources</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold">95%</div>
            <div className="text-sm opacity-85">Success Rate</div>
          </div>
        </div>
      </section>

      {/* Subjects Section */}
      <section id="subjects" className="py-20 px-8 max-w-6xl mx-auto">
        <h2 className="text-5xl font-bold text-center mb-12">Explore All Subjects</h2>
        <p className="text-center text-gray-600 mb-12 text-lg">Comprehensive study materials for every subject</p>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            { icon: '📐', title: 'Mathematics', desc: 'Algebra, Calculus, Geometry & Statistics', chapters: '120+' },
            { icon: '⚛️', title: 'Physics', desc: 'Mechanics, Waves, Thermodynamics & More', chapters: '95+' },
            { icon: '🧪', title: 'Chemistry', desc: 'Organic, Inorganic & Physical Chemistry', chapters: '110+' },
            { icon: '🧬', title: 'Biology', desc: 'Botany, Zoology, Genetics & Ecology', chapters: '105+' },
            { icon: '📚', title: 'English', desc: 'Literature, Grammar, Reading & Essays', chapters: '80+' },
            { icon: '🌍', title: 'Social Studies', desc: 'History, Geography, Civics & Economics', chapters: '130+' },
            { icon: '💼', title: 'Business Studies', desc: 'Organization, Finance & Accounting', chapters: '75+' },
            { icon: '🔢', title: 'Accountancy', desc: 'Financial Accounting & Advanced Topics', chapters: '85+' },
          ].map((subject, idx) => (
            <div 
              key={idx}
              className="bg-white border border-gray-200 rounded-xl p-8 text-center hover:border-purple-500 hover:shadow-xl hover:-translate-y-2 transition"
            >
              <div className="text-5xl mb-4">{subject.icon}</div>
              <h3 className="text-xl font-bold mb-2">{subject.title}</h3>
              <p className="text-gray-600 text-sm mb-4">{subject.desc}</p>
              <span className="inline-block bg-gradient-to-r from-purple-500 to-pink-600 text-white text-xs font-bold px-4 py-2 rounded-full">
                {subject.chapters} Chapters
              </span>
            </div>
          ))}
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="bg-gray-50 rounded-2xl py-20 px-8 mx-4 max-w-6xl mx-auto">
        <h2 className="text-5xl font-bold text-center mb-16">Why Choose CBSE Study Hub?</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {[
            { icon: '✅', title: 'Expert Curated Content', desc: 'Created by top educators with years of CBSE teaching experience' },
            { icon: '🎯', title: 'Latest Syllabus', desc: 'Updated with latest CBSE curriculum changes and board patterns' },
            { icon: '📱', title: 'Mobile Friendly', desc: 'Study on the go with our fully responsive design' },
            { icon: '💰', title: '100% Free', desc: 'No subscriptions, no hidden charges. Quality learning for all' },
          ].map((feature, idx) => (
            <div key={idx} className="text-center">
              <div className="text-5xl mb-4">{feature.icon}</div>
              <h3 className="text-2xl font-bold mb-3">{feature.title}</h3>
              <p className="text-gray-600">{feature.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Metrics Section */}
      <section className="py-20 px-8 max-w-6xl mx-auto">
        <h2 className="text-5xl font-bold text-center mb-12">By The Numbers</h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {[
            { number: '4.8⭐', label: 'User Rating' },
            { number: '500K+', label: 'Downloads' },
            { number: '98%', label: 'Content Accuracy' },
            { number: '24/7', label: 'Availability' },
          ].map((metric, idx) => (
            <div key={idx} className="bg-gray-50 p-6 rounded-xl text-center border border-gray-200">
              <div className="text-4xl font-bold bg-gradient-to-r from-purple-500 to-pink-600 bg-clip-text text-transparent">
                {metric.number}
              </div>
              <div className="text-gray-600 mt-2">{metric.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-20 px-8 max-w-6xl mx-auto">
        <h2 className="text-5xl font-bold text-center mb-12">What Students Say</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { stars: 5, text: '"These notes are lifesavers! Cleared my concepts in just 2 weeks. The explanations are so clear."', avatar: 'AR', name: 'Arjun Reddy', location: 'Class 12, Delhi' },
            { stars: 5, text: '"Best free resource for CBSE! Better than paid coaching materials. Highly recommend!"', avatar: 'PS', name: 'Priya Singh', location: 'Class 12, Mumbai' },
            { stars: 5, text: '"Scored 95% in Physics thanks to these explanations! The practice questions were great."', avatar: 'NK', name: 'Nikhil Kumar', location: 'Class 12, Bangalore' },
            { stars: 5, text: '"Improved from 65% to 88% in Chemistry. The past papers helped a lot with exam prep."', avatar: 'SK', name: 'Sneha Kapoor', location: 'Class 12, Hyderabad' },
            { stars: 5, text: '"Every concept is broken down into bite-sized pieces which makes learning fun!"', avatar: 'VJ', name: 'Varun Joshi', location: 'Class 12, Pune' },
            { stars: 5, text: '"All subjects in one place, free, and super organized. Can\'t ask for more!"', avatar: 'IA', name: 'Ishita Agarwal', location: 'Class 12, Kolkata' },
          ].map((testimonial, idx) => (
            <div key={idx} className="bg-white border border-gray-200 rounded-xl p-6">
              <div className="text-yellow-400 mb-3">{'⭐'.repeat(testimonial.stars)}</div>
              <p className="text-gray-600 italic mb-6">{testimonial.text}</p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-r from-purple-500 to-pink-600 text-white flex items-center justify-center font-bold text-xs">
                  {testimonial.avatar}
                </div>
                <div>
                  <p className="font-semibold text-gray-800">{testimonial.name}</p>
                  <p className="text-xs text-gray-600">{testimonial.location}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-purple-500 via-purple-600 to-pink-600 text-white py-16 px-8 my-12 rounded-2xl max-w-6xl mx-auto">
        <h2 className="text-4xl font-bold text-center mb-4">Join Thousands of Successful Students</h2>
        <p className="text-center opacity-90 mb-8">Get instant access to study notes, practice questions & past papers</p>
        <div className="max-w-md mx-auto">
          <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); alert('🎉 Thanks for subscribing! Check your email for exclusive content.'); e.target.reset(); }}>
            <input 
              type="email" 
              placeholder="Enter your email address" 
              required
              className="flex-1 px-4 py-3 rounded-lg text-gray-800 focus:outline-none"
            />
            <button type="submit" className="bg-white text-purple-600 px-6 py-3 rounded-lg font-semibold hover:shadow-lg transition">
              Get Started
            </button>
          </form>
          <p className="text-center text-xs opacity-70 mt-3">No spam, unsubscribe anytime</p>
        </div>
      </section>

      {/* Footer */}
      <footer id="contact" className="bg-gray-50 py-12 px-8 border-t border-gray-200">
        <p className="text-center text-gray-600 mb-6">© 2024 CBSE Study Hub. Made with ❤️ for students, by educators.</p>
        <div className="flex justify-center gap-8 flex-wrap mb-6">
          <a href="#subjects" className="text-purple-600 hover:text-pink-600 transition">About</a>
          <a href="#features" className="text-purple-600 hover:text-pink-600 transition">Features</a>
          <a href="#testimonials" className="text-purple-600 hover:text-pink-600 transition">Testimonials</a>
          <a href="mailto:contact@cbsestudyhub.com" className="text-purple-600 hover:text-pink-600 transition">Contact Us</a>
          <a href="#" className="text-purple-600 hover:text-pink-600 transition">Privacy Policy</a>
        </div>
        <p className="text-center text-gray-600">Made with passion to help students succeed in CBSE</p>
      </footer>
    </>
  );
}
